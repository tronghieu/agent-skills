# Plain-HTML track

Use this when you want zero setup: a single `index.html` that runs by double-clicking it
in a browser. No Node, no build, no server. Best for quick decks, sharing a file someone
can open anywhere, or environments without a toolchain.

## Scaffold

```bash
bash scripts/new-html-deck.sh <deck-name> [target-dir] [--title "Deck title"]
```

Creates `<deck-name>/index.html`, `<deck-name>/assets/`, and a `<deck-name>-notes.md`
speaker-notes file. Open with `open <deck-name>/index.html`.

## How the template works

- **Fluid layout.** Slides are positioned `absolute; inset:0` inside `#viewport` and fill
  the whole screen at any aspect ratio — no fixed stage, so **no letterbox/pillarbox bars**
  on 16:10 laptops, ultrawides, or resized windows. Type scales with `clamp(min, vw/vh,
  max)` so it stays projection-legible; spacing uses `em`/`%`/`vh`. There is nothing to
  scale on resize.
- **Slides** are `<section class="slide">` elements inside `#stage`. The first has
  `class="slide active"`. JS shows one at a time and cross-fades.
- **Navigation** (required) is the bottom `#nav`: prev/next buttons, a generated dot
  strip, and a `current / total` counter. Keyboard: → / Space / PageDown / ← / PageUp /
  Home / End.
- **Tailwind** loads from CDN (`cdn.tailwindcss.com`) so utility classes work with no
  build. The base typography (`.slide h1`, `.slide li`, etc.) is defined in `<style>` to
  enforce the floor; you can still add Tailwind classes on elements.

## Adding / editing slides

- Duplicate a `<section class="slide">...</section>` block and edit it. Order in the file
  is the slide order; dots and counter update automatically.
- Use fluid units for any new sizing: `clamp(min, vw/vh, max)` for type, `em`/`%`/`vh`
  for spacing and max-widths. Pick the `max` from each role's range in
  `references/design-system.md` based on how much content the slide holds — tighten toward
  the floor on text-heavy slides so nothing overflows, open up on sparse/hero slides.
  Never below the floor (body 40px, caption 32px). Don't hard-code fixed px.
- Put images in `assets/` and reference them with a relative path (`assets/foo.png`).
- For a step reveal, give elements `style="opacity:0"` and flip them on a click/keyboard
  handler — but prefer splitting into more slides; it's simpler and more robust.

## When to switch to the React track instead

Move to Vite + React if the deck needs: many slides with shared components, complex
state-driven interactions, TypeScript safety, Framer Motion orchestration, or a embedded
live demo. The plain-HTML file gets unwieldy past ~15–20 rich slides.
